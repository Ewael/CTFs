RULES:
- If you need logcat to debug, please use HDFR tag
    --> only HDFR tag will be printed back to you
- One request per minute is allowed, and it needs to be a new apk
- No attacks will be tolerated

USAGE:
1.Push your apk by using : curl -F "file=@Pentest-6ixwine.apk" http://51.75.253.36/sixwine.php
2.Wait for logcat return filtered by "HDFR" tag


Have fun, do not hesitate to DM me on discord for questions --> Octopu$
